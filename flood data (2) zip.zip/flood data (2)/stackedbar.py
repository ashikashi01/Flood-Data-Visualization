import pandas as pd
import matplotlib.pyplot as plt

# Replace 'your_file.csv' with the actual file path
file_path = 'cr.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Assuming you have a DataFrame with columns 'UEI', 'Severity', 'Human fatality', 'Human injured', etc.
# Replace these column names with your actual column names

# Plotting a stacked bar chart
df.plot(kind='bar', stacked=True, x='UEI', y=['Severity', 'Human fatality', 'Human injured', 'Human Displaced', 'Animal Fatality'])

# Customize the plot (add labels, title, etc.)
plt.xlabel('UEI')
plt.ylabel('Count')
plt.title('Stacked Bar Chart')

# Show the plot
plt.show()
