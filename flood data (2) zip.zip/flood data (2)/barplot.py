import pandas as pd
import matplotlib.pyplot as plt

# Replace 'your_file.csv' with the actual file path
file_path = 'cr.csv'

# Read CSV file into a DataFrame
df = pd.read_csv(file_path)

# Change the attribute to the desired column name
desired_column_name = 'Districts'

# Assuming you have a column named 'Severity' in your DataFrame
# Make sure to use the correct column name
counts = df[desired_column_name].value_counts()

# Plot bar chart
counts.plot(kind='bar', color='skyblue')

# Customize plot
plt.title(f'Bar Chart of {desired_column_name}')
plt.xlabel(desired_column_name)
plt.ylabel('Count')

# Show plot
plt.show()
