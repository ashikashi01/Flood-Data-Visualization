import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Replace 'your_file.csv' with the actual file path
file_path = 'cr.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Check and filter numeric columns
numeric_columns = df.select_dtypes(include=['number']).columns

# Check if there are numeric columns
if not numeric_columns.empty:
    # Generate random numeric data for demonstration
    np.random.seed(42)
    df_numeric = pd.DataFrame(np.random.randint(1, 10, size=(len(df), len(numeric_columns))), columns=numeric_columns)

    # Plotting a stacked area chart
    df_numeric.set_index(df['UEI']).T.plot(kind='area', stacked=True)

    # Customize the plot (add labels, title, etc.)
    plt.xlabel('UEI')
    plt.ylabel('Count')  # You might need to adjust this based on your data
    plt.title('Stacked Area Chart')

    # Add a legend (if needed)
    plt.legend(title='Legend', loc='upper left')

    # Show the plot
    plt.show()
else:
    print("No numeric columns found for plotting.")
