import pandas as pd
import matplotlib.pyplot as plt

# Replace 'your_file.csv' with the actual file path
file_path = 'cr.csv'

# Read CSV file into a DataFrame
df = pd.read_csv(file_path)

# Plot histogram
plt.hist(df['Duration(Days)'], bins=10, color='blue', edgecolor='black')

# Customize plot
plt.title('Duration Distribution')
plt.xlabel('Duration (Days)')
plt.ylabel('Frequency')

# Show plot
plt.show()
