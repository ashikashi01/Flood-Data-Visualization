import plotly.express as px
import pandas as pd

try:
    # Your dataset
    data = pd.read_csv('C:/Users/sambh/Downloads/flood data (2)/cr.csv')

    print(data.head())  # Check the first few rows of the dataframe
    print(data.info())  # Get information about the dataframe

    # Correct column name with extra space
    data.rename(columns={"Extent of damage ": "Extent of damage"}, inplace=True)

    # Plotly choropleth map
    fig = px.choropleth(
        data_frame=data,
        locations="Districts",
        locationmode="country names",
        color="Human fatality",
        hover_name="Extent of damage",
        color_continuous_scale=px.colors.sequential.Plasma,
        title="Human Fatality Choropleth Map (by Country)"
    )

    # Save the map as an HTML file
    fig.write_html("choropleth_map.html")

    # Display the map in the Python environment
    fig.show()

    # Calculate human fatality rate
    total_events = len(data)
    total_fatalities = data['Human fatality'].sum()
    human_fatality_rate = (total_fatalities / total_events) * 100

    print(f"Human Fatality Rate: {human_fatality_rate:.2f}%")

except Exception as e:
    print(f"An error occurred: {e}")
